package com.example.artistmgr;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class PagerAdapter extends FragmentStatePagerAdapter {

    int noOFTabs;
    public PagerAdapter(FragmentManager fm, int numOfTabs){
        super(fm);
        this.noOFTabs = numOfTabs;
    }
    @Override
    public Fragment getItem(int position) {
         switch(position){
             case 0:
                 DeleteArtistTab dat = new DeleteArtistTab();
                 return dat;

             case 1:
                 DeletePhotoTab dpt = new DeletePhotoTab();
                 return dpt;

             default:
                 return null;
         }
    }

    @Override
    public int getCount() {
        return 0;
    }
}
