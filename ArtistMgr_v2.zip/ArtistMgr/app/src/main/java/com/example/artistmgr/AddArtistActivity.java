package com.example.artistmgr;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddArtistActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    EditText editArtistName;
    Button btnAddArtist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_artist);
        editArtistName = (EditText) findViewById(R.id.addArtistText);
        btnAddArtist = (Button) findViewById(R.id.btnAddArtist);
    }

    public void addData(View view){
        DatabaseHelper db = new DatabaseHelper(this);
        boolean insertedToDatabase = db.save(editArtistName.getText().toString());
        if (insertedToDatabase){
            Toast t = Toast.makeText(getApplicationContext(), "Sucessfully inserted artist to database! ", Toast.LENGTH_LONG);
            t.show();
        }else{
            Toast t = Toast.makeText(getApplicationContext(), "Artist not inserted to database ", Toast.LENGTH_LONG);
            t.show();
        }

    }

}
