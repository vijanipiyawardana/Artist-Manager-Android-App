package com.example.artistmgr;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDB = new DatabaseHelper(this);
    }
    public void addArtist(View view){
        Intent intent = new Intent(this, AddArtistActivity.class);
        startActivity(intent);
    }
    public void addPhoto(View view){
        Intent intent = new Intent(this, AddPhotoActivity.class);
        startActivity(intent);
    }
    public void deleteArtistOrPhoto(View view){
        Intent intent = new Intent(this, DeleteArtistOrPhoto.class);
        startActivity(intent);
    }

    public void viewPhotos(View view){
        Intent intent = new Intent(this, PhotoGallery.class);
        startActivity(intent);
    }
}
