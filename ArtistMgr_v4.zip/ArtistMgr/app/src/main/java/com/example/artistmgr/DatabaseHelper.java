package com.example.artistmgr;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper implements BaseColumns {

    public static final String DATABASE_NAME = "Artist.db";

    public DatabaseHelper(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, 1);
    }

    //public static final String ARTIST_TABLE = "artist_table";
    //public static final String ARTIST_ID = "artist_id";
    //public static final String ARTIST_NAME = "artist_name";

    //public static final String PHOTO_TABLE = "photo_table";
    //public static final String PHOTO_ID = "photo_id";
    //public static final String PHOTO_NAME = "photo_name";
    //public static final String CAT_ID = "category_id";
    //public static final String OWNER_ID = "owner_id";

    //public static final String CATEGORY_TABLE = "category_table";
    //public static final String CATEGORY_ID = "photo_category_id";
    //public static final String CATEGORY_NAME = "photo_category_name";

    /*
    public static final String SQL_CREATE_TABLE_ARTIST = "CREATE TABLE " + ARTIST_TABLE +" ("
            + ARTIST_ID + " integer PRIMARY KEY AUTOINCREMENT, "
            + ARTIST_NAME + " text "
            +");";

    public static final String SQL_CREATE_TABLE_PHOTO_CATEGORY = "CREATE TABLE " + CATEGORY_TABLE +" ("
            + CATEGORY_ID + " integer PRIMARY KEY AUTOINCREMENT, "
            + CATEGORY_NAME + " text "
            +");";

    public static final String SQL_CREATE_TABLE_PHOTO = "CREATE TABLE " + PHOTO_TABLE +" ("
            + PHOTO_ID + " integer PRIMARY KEY AUTOINCREMENT, "
            + PHOTO_NAME+" text, "
            + CAT_ID+" integer, "
            + OWNER_ID+ " integer "
            +");";

    */

    //public DatabaseHelper(Context context) {
    //    super(context.getApplicationContext(), DATABASE_NAME, null,1);
    //}

    @Override
    public void onCreate(SQLiteDatabase db) {

        String SQL_CREATE_TABLE_ARTIST =
                "CREATE TABLE " + ArtistsMaster.Artists.ARTIST_TABLE + " (" +
                        ArtistsMaster.Artists._ID + " INTEGER PRIMARY KEY," +
                        ArtistsMaster.Artists.ARTIST_NAME + " TEXT)";


        String SQL_CREATE_TABLE_PHOTO_CATEGORY =
                "CREATE TABLE " + ArtistsMaster.PhotoCategories.CATEGORY_TABLE + " (" +
                        ArtistsMaster.PhotoCategories._ID + " INTEGER PRIMARY KEY," +
                        ArtistsMaster.PhotoCategories.CATEGORY_NAME + " TEXT)";

        String SQL_CREATE_TABLE_PHOTO =
                "CREATE TABLE " + ArtistsMaster.Photos.PHOTO_TABLE + " (" +
                        ArtistsMaster.Photos._ID + " INTEGER PRIMARY KEY," +
                        ArtistsMaster.Photos.PHOTO_NAME + " TEXT," +
                        ArtistsMaster.Photos.CAT_ID + " INTEGER," +
                        ArtistsMaster.Photos.OWNER_ID + "INTEGER)";

        db.execSQL(SQL_CREATE_TABLE_ARTIST);
        db.execSQL(SQL_CREATE_TABLE_PHOTO_CATEGORY);
        db.execSQL(SQL_CREATE_TABLE_PHOTO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       // db.execSQL("DROP TABLE IF EXISTS " + ARTIST_TABLE);
       // db.execSQL("DROP TABLE IF EXISTS " + CATEGORY_TABLE);
       // db.execSQL("DROP TABLE IF EXISTS " + PHOTO_TABLE);
       onCreate(db);
    }

    public boolean save(String name){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ArtistsMaster.Artists.ARTIST_NAME, name);
        long newRowId = db.insert(ArtistsMaster.Artists.ARTIST_TABLE, null, values);
        if(newRowId >=1)
            return true;
        else
            return false;
    }


  /*  public boolean save(String name){
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        SQLiteDatabase db = this.getWritableDatabase();
        long updateRecordCount = 0;
        updateRecordCount = db.insert(ARTIST_TABLE, null, cv);
        db.close();
        return updateRecordCount > 0 ?  true: false;
    }*/

  /*  public boolean addCategory(String category){
        ContentValues cv = new ContentValues();
        cv.put("category", category);
        SQLiteDatabase db = this.getWritableDatabase();
        long updateRecordCount = 0;
        updateRecordCount = db.insert(CATEGORY_TABLE, null, cv);
        db.close();
        return updateRecordCount > 0 ?  true: false;
    }*/

    ////////////////////////// method 1

    public ArrayList<String> getAllArtists(){
       /* ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db =  this.getReadableDatabase();
        db.beginTransaction();
        try {
            //String selectQuery = "SELECT " + ARTIST_NAME + " FROM " + ARTIST_TABLE;
            String selectQuery = "SELECT * FROM " + ARTIST_TABLE;
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String aName = cursor.getString(cursor.getColumnIndex("name"));
                    list.add(aName);
                }
            }
            db.setTransactionSuccessful();
        }catch (Exception e){
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return  list;
        */
       return null;
    }


    /////////////////////////////////////

    ////////////////////// method two

    //////////////////////////////////////


    ////////////////////////method one

    public ArrayList<String> getCategories(){

       /* ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db =  this.getReadableDatabase();
        db.beginTransaction();
        try {
            //String selectQuery = "SELECT " + ARTIST_NAME + " FROM " + ARTIST_TABLE;
            String selectQuery = "SELECT * FROM " + CATEGORY_TABLE;
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String cName = cursor.getString(cursor.getColumnIndex("category"));
                    list.add(cName);
                }
            }
            db.setTransactionSuccessful();
        }catch (Exception e){
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return  list;
        */
       return null;
    }



    /////////////////////////// method two
    /*
    public ArrayList<String> getCategoriesTwo(){
        SQLiteDatabase db = getReadableDatabase();

        String[] projection = {
                CATEGORY_ID, CATEGORY_NAME
        };

        Cursor cursor = db.query(
                CATEGORY_TABLE,
                projection,
                null,
                null,
                null,
                null,
                null
        );
        ArrayList<String> categories = new ArrayList<>();

        while(cursor.moveToNext()){
            String category = cursor.getString(cursor.getColumnIndexOrThrow(CATEGORY_NAME));
            categories.add(category);
        }
        cursor.close();
        return categories;
    }
    *///////////////////////////////////////////////////////////

    public String getOneArtist(){
        return null;
    }

    public void savePhoto(){

    }

    public void deleteArtist(){

    }

    public void deletePhoto(){

    }

    public ArrayList<String> getAllPhotos(){
        return null;
    }


}
