package com.example.artistmgr;

import android.provider.BaseColumns;

public class ArtistsMaster  {
    public ArtistsMaster() {
    }

    // inner class to define artist table contents
    public static class Artists implements BaseColumns{
        public static final String ARTIST_TABLE = "artist_table";
        //public static final String ARTIST_ID = "artist_id";
        public static final String ARTIST_NAME = "artist_name";
    }

    // inner class to define photo_categories table contents
    public static class PhotoCategories implements BaseColumns{
        public static final String CATEGORY_TABLE = "category_table";
        //public static final String CATEGORY_ID = "photo_category_id";
        public static final String CATEGORY_NAME = "photo_category_name";
    }

    // inner class to define photo table contents
    public static class Photos implements BaseColumns{
        public static final String PHOTO_TABLE = "photo_table";
        //public static final String PHOTO_ID = "photo_id";
        public static final String PHOTO_NAME = "photo_name";
        public static final String CAT_ID = "category_id"; // foreign key for category table ?
        public static final String OWNER_ID = "owner_id"; // foreign key for artist table ?
    }


}
